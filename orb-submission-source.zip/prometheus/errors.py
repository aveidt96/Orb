class PrometheusError(Exception):
    pass
